<div align="center">

<!-- HERO -->
<img src="./hero.svg?v=1" alt="Hi, I'm Rohan Bhowmik — AI ML and Data Science Developer" width="100%"/>

<br/><br/>

<!-- WHAT I BUILD + LIFE OUTSIDE CODE -->
<img src="./about-life.svg?v=1" alt="What I build and what I am learning" width="100%"/>

<br/><br/>

<!-- TECH STACK -->
<img src="./stack.svg?v=1" alt="Rohan Bhowmik tech stack" width="100%"/>

<br/><br/>

<!-- DEVELOPER ID + DASHBOARD -->
<img src="./id-dashboard.svg?v=1" alt="Developer ID and dashboard" width="100%"/>

<br/><br/>

</div>

## 🚀 Featured builds

| Project | What it is | Stack |
|:---|:---|:---:|
| [**FraudX — Agentic Fraud Investigation**](https://github.com/rohanbhowm25308/FraudX) | Agentic workflow for investigating suspicious transactions and fraud patterns | `Python` `AI Agents` `TigerGraph` |
| [**Orchestrator AI**](https://github.com/rohanbhowm25308) | Intelligent decision-making and task orchestration application | `Python` `Flask` `AI` |
| [**Nova AI Career Recommendation Engine**](https://github.com/rohanbhowm25308) | AI-driven career exploration and recommendation experience | `GenAI` `Python` `Web` |
| [**ProjectDNA AI Recommender**](https://github.com/rohanbhowm25308/ProjectDNA-AI-Recommender) | AI-powered project discovery and recommendation system | `Python` `GenAI` `RAG` |
| [**Sentiment Analysis Dashboard**](https://github.com/rohanbhowm25308) | NLP dashboard for classifying and visualizing sentiment | `Python` `NLP` `Flask` |
| [**ChurnScope — Customer Churn Analytics**](https://github.com/rohanbhowm25308/ChurnScope-Customer-Churn-Analytics) | End-to-end customer churn analysis and machine-learning workflow | `Python` `Pandas` `Scikit-learn` |

<div align="center">

<br/>

## 🌃 My contribution city

*Every commit adds another block to the city — rebuilt automatically every day.*

<img src="./profile-3d-contrib/profile-night-view.svg" alt="3D contribution city" width="100%"/>

<br/><br/>

<!-- CONNECT -->
<img src="./connect.svg?v=1" alt="Let's connect" width="100%"/>

<a href="https://github.com/rohanbhowm25308"><img src="https://img.shields.io/badge/GitHub-ff3b30?style=for-the-badge&logo=github&logoColor=ffffff" alt="GitHub"/></a>
<a href="https://www.linkedin.com/in/rohan-bhowmik-b014473a1/"><img src="https://img.shields.io/badge/LinkedIn-e11d48?style=for-the-badge&logo=linkedin&logoColor=ffffff" alt="LinkedIn"/></a>
<a href="mailto:bhowmikrohan83@gmail.com"><img src="https://img.shields.io/badge/Email-b91c1c?style=for-the-badge&logo=gmail&logoColor=ffffff" alt="Email"/></a>

<br/><br/>

<img src="https://komarev.com/ghpvc/?username=rohanbhowm25308&color=ef4444&style=for-the-badge&label=PROFILE+VIEWS" alt="Profile views"/>

<br/>

**Always learning. Always building. Always exploring AI.** 🔴

</div>
