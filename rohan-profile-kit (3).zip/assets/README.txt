Drop your personal art here, then run:  python3 build.py

  hello.mp4   (or .mov / .webm / .gif)  a 2-second clip of you waving   -> plays inside the hero
  hero.jpg    (or .png)                 a still photo (used if no clip)  -> hero
  portrait.jpg (or .png)                head-and-shoulders photo         -> ID badge  (falls back to hero.jpg)
  character.png                         transparent PNG, pointing pose   -> "Let's connect" banner

Anything missing falls back to a red "R" monogram, so the profile always looks finished.
